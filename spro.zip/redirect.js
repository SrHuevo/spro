var url = document.location.href

document.location.href = url.replace(/http:\/\/streamcloud\.eu/, 'http://streamcloud.pro')